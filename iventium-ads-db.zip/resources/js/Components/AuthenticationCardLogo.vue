<script setup>
import { Link } from "@inertiajs/inertia-vue3";
</script>

<template>
    <Link :href="'/'">
        <img src="/icon.png" alt="iventium icon" class="w-24 h-24" />
    </Link>
</template>
