<template>
    <img src="/logo.png" alt="" />
</template>
