<template>
    <button
        :type="type"
        class="inline-flex items-center px-4 py-2 bg-purple-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-purple-600 active:bg-purple-900 focus:outline-none focus:border-purple-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition"
        @click="visit"
    >
        <slot></slot>
    </button>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
    props: {
        type: {
            type: String,
            default: "submit",
        },

        href: {},
    },

    methods: {
        visit(event) {
            if (!this.href) {
                return;
            }

            event.preventDefault();

            this.$inertia.visit(this.href);
        },
    },
});
</script>
