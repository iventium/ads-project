<template>
    <div class="pb-4 bg-white overflow-hidden shadow-xl sm:rounded-lg mt-4">
        <slot></slot>
    </div>
</template>

<script>
export default {};
</script>
