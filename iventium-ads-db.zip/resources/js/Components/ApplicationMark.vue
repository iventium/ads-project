<template>
    <img src="/icon.png" alt="" />
</template>
